#!/usr/bin/python3

import time
from collections import defaultdict
from scapy.all import sniff, IP

# Parametre
INTERFACE = 'wlan0'  #siet
PACKET_THRESHOLD = 10  # pocet paketov na detegovanie
TIME_WINDOW = 60  # cas, za kolko pride predurceny pocet paketov

# list na ulozenie poctu paketov na IP adresu
ip_counts = defaultdict(list)

def detect_intrusion(ip):
    current_time = time.time()
    # odstranenie neauktalnych timestampov
    ip_counts[ip] = [t for t in ip_counts[ip] if current_time - t <= TIME_WINDOW]
    # pridanie timestampu
    ip_counts[ip].append(current_time)
    # kontrola ci bol threshold presiahnuty
    if len(ip_counts[ip]) > PACKET_THRESHOLD:
        print(f"[!] Possible intrusion from IP: {ip}")

def packet_callback(packet):
    if IP in packet:
        src_ip = packet[IP].src
        detect_intrusion(src_ip)

def main():
    print(f"Starting IDS on interface {INTERFACE}...")
    sniff(iface=INTERFACE, prn=packet_callback, store=False)

if __name__ == "__main__":
    main()
