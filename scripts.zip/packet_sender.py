#!/usr/bin/python3

from os import system
from scapy.all import *

def create_packet():
    pkt_type = input("TCP alebo UDP [1/2]: ").strip()
    src_mac = input("Zadaj zdrojovú MAC adresu [d pre originálnu]: ").strip()
    dst_mac = input("Zadaj cieľovú MAC adresu [d pre originálnu]: ").strip()
    src_addr = input("Zadaj zdrojovú IP adresu: ").strip()
    dst_addr = input("Zadaj cieľovú IP adresu: ").strip()
    t_t_l_input = input("Zadaj TTL [0/d pre 64]: ").strip()
    if src_mac == "d":
    	src_mac = "ff:ff:ff:ff:ff:ff"

    if dst_mac == "d":
    	dst_mac = "ff:ff:ff:ff:ff:ff"

    # Handle TTL input
    if t_t_l_input.lower() in ["0", "d"]:
        ttl_value = 64
    else:
        try:
            ttl_value = int(t_t_l_input)
        except ValueError:
            print("Neplatný TTL, nastavené na 64")
            ttl_value = 64

    layer_3 = IP(src=src_addr, dst=dst_addr, ttl=ttl_value)
    layer_2 = Ether(src=src_mac, dst=dst_mac)

    if pkt_type == "1":
        d_port = input("Zadaj destination port: ").strip()
        try:
            d_port_int = int(d_port)
        except ValueError:
            print("Neplatný port, nastavené na 80")
            d_port_int = 80
        packet = layer_2 / layer_3 / TCP(dport=d_port_int)
    elif pkt_type == "2":
        d_port = input("Zadaj destination port: ").strip()
        try:
            d_port_int = int(d_port)
        except ValueError:
            print("Neplatný port, nastavené na 80")
            d_port_int = 80
        packet = layer_2 / layer_3 / UDP(dport=d_port_int)
        print(packet)
        input("Stlačte Enter pre pokračovanie...")
    else:
        print("Neznámy typ paketu.")
        return None

    return packet

def main():
    while True:
        create_choice = input("Chceš vytvoriť paket? [y/n]: ").strip().lower()
        if create_choice == "n":
            break
        elif create_choice == "y":
            packet = create_packet()
            if packet is None:
                continue
            send_choice = input("Chceš odoslať paket? [y/n]: ").strip().lower()
            if send_choice == "y":
                send(packet)
                print("Packet odoslaný.")
                print(packet)
        else:
            print("Neplatná voľba, skúste znova.")

if __name__ == "__main__":
    main()


