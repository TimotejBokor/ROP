#!/usr/bin/bash

banner(){
	#vykresli banner
	echo "#   #  ##  #  # # ###  ###   ##  #  # ### "
	echo "## ## #  # ## # # #  # #  # #  # ## # #   "
	echo "# # # #  # # ## # #  # ###  #  # # ## ### "
	echo "#   # #  # #  # # #  # #  # #  # #  # #   "
	echo "#   #  ##  #  # # ###  #  #  ##  #  # ### "

}

main(){
	banner
	sleep 2
	select script in sniffer sender ids mitm vuln_scan exit
	do
		case $script in
			sniffer )
				read -p "[+] Zadaj Interface: " intface
				python3 $wrdir/packet_sniffer_2.py --interface $intface
			;;
			sender )
				python3 $wrdir/packet_sender.py
			;;
			ids )
				python3 $wrdir/truthseeker.py
			;;
			mitm )
				python3 $wrdir/mitm.py
			;;
			vuln_scan )
				python3 $wrdir/vuln_scan.py
			;;
			exit )
				exit 0
			;;
		esac
	done
	# dostane uzivatela do zakladeho menu, a odtial si vybera, ktory skript chce spustit
}


wrdir=$PWD

main
